"""One command, every feature.

    uv run python evals/run_all.py                 # all suites, offline
    uv run python evals/run_all.py --only montage  # one suite
    uv run python evals/run_all.py --live          # also the checks that call Gemini (need GOOGLE_API_KEY)
    uv run python evals/run_all.py --no-fail       # always exit 0 (when you only want the report)

Writes evals/results/run-<time>.json, latest.json and evals/results/report.md, and shows what changed since the last run.
Exit status 1 when a gate fails (so CI can block a merge that makes a feature worse).
"""
from __future__ import annotations

import argparse
import datetime as dt
import importlib
import pkgutil
import platform
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from evals import core, suites as suites_pkg                                   # noqa: E402


def discover() -> list:
    mods = []
    for info in pkgutil.iter_modules(suites_pkg.__path__):
        if not info.name.startswith("_"):
            mods.append(importlib.import_module(f"evals.suites.{info.name}"))
    return sorted(mods, key=lambda m: m.NAME)


def fmt(m: dict) -> str:
    v = m["value"]
    if v is None:
        return "-"
    return (f"{v:.1f}" if abs(v) >= 10 else f"{v:.3g}") + (f" {m['unit']}" if m["unit"] else "")


def gate_text(m: dict) -> str:
    return "" if m["gate"] is None else f"{'≥' if m['higher_is_better'] else '≤'} {m['gate']:g}"


def render(run: dict, previous: dict | None) -> str:
    old = core.index(previous)
    lines = [f"# Evaluation report", f"Run {run['started']} on {run['platform']}. Every number comes from running the code in this repository.", ""]
    s = run["summary"]
    lines += [f"**{s['PASS']} passed · {s['FAIL']} failed · {s['SKIPPED']} skipped · {s['INFO']} info**", ""]
    for suite in run["suites"]:
        lines += [f"## {suite['name']}", suite["description"], "",
                  "| metric | value | gate | status | since last run | what it means |", "|---|---|---|---|---|---|"]
        for m in suite["metrics"]:
            lines.append(f"| {m['name']} | {fmt(m)} | {gate_text(m)} | {m['status']} | {core.change(old.get((suite['name'], m['name'])), m)} | {m['note']} |")
        if suite.get("error"):
            lines += ["", f"**Suite crashed:** `{suite['error']}`"]
        lines.append("")
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", nargs="*", help="suite names to run")
    ap.add_argument("--live", action="store_true", help="also run checks that call Gemini or the internet")
    ap.add_argument("--no-fail", action="store_true")
    args = ap.parse_args()

    previous = core.load_latest()
    started = dt.datetime.now().astimezone()
    run = {"started": started.isoformat(timespec="seconds"), "platform": platform.platform(), "live": args.live, "suites": []}
    ctx = {"live": args.live}
    for mod in discover():
        if args.only and mod.NAME not in args.only:
            continue
        entry = {"name": mod.NAME, "description": mod.DESCRIPTION, "metrics": [], "error": ""}
        try:
            entry["metrics"] = [m.as_dict() for m in mod.run(ctx)]
        except Exception as e:                                                  # noqa: BLE001 - one broken suite must not hide the others
            traceback.print_exc()
            entry["error"] = f"{type(e).__name__}: {e}"[:300]
        run["suites"].append(entry)
    counts = {k: 0 for k in ("PASS", "FAIL", "SKIPPED", "INFO")}
    for s in run["suites"]:
        for m in s["metrics"]:
            counts[m["status"]] += 1
        counts["FAIL"] += 1 if s["error"] else 0
    run["summary"] = counts
    core.RESULTS.mkdir(parents=True, exist_ok=True)
    report = render(run, previous)
    (core.RESULTS / "report.md").write_text(report, encoding="utf-8")
    core.save_run(run, started.strftime("%Y%m%d-%H%M%S"))
    print(report)
    print(f"\nSaved: {core.RESULTS / 'report.md'}")
    return 0 if args.no_fail or counts["FAIL"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
