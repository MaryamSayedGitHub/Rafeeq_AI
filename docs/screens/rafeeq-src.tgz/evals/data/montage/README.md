# Labelled recordings for the montage live metrics

Put real lecture clips here (2 to 5 minutes each is enough; keep the files small, do not commit large videos):

```
evals/data/montage/lecture1.mp4
evals/data/montage/lecture1.json
```

`lecture1.json` is what YOU know is true:

```json
{
  "transcript": "the exact words said in the clip, written by hand",
  "chapter_starts": [0, 95, 210]
}
```

`uv run python evals/run_all.py --only montage --live` then reports **caption_wer** (word error rate of Gemini's captions against
your transcript, with diacritics and ة/ه, أ/ا ignored) and **chapter_position_error** (average seconds between each
chapter start you wrote and the nearest one the model suggested). It needs `GOOGLE_API_KEY` and calls Gemini.
