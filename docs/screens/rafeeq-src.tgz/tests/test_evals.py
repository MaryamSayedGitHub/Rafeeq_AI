"""The evaluation pipeline itself: its metric helpers must be right, or every report is wrong."""
import shutil

import pytest

from evals import core

HAS_FFMPEG = bool(shutil.which("ffmpeg") and shutil.which("ffprobe"))


def test_wer_counts_word_errors_and_ignores_arabic_spelling_noise():
    assert core.wer("the cat sat", "the cat sat") == 0.0
    assert core.wer("the cat sat", "the dog sat") == pytest.approx(1 / 3)
    assert core.wer("a b c d", "") == 1.0 and core.wer("", "") == 0.0
    assert core.wer("مَرْحَبًا بِكُمْ في الدرس", "مرحبا بكم في الدرس") == 0.0       # diacritics are not errors
    assert core.wer("المدرسة إلى", "المدرسه الى") == 0.0                              # ة/ه and أإآ/ا


def test_range_helpers():
    assert core.overlap([(0, 5), (9, 14)], [(4, 10)]) == 2.0
    assert core.length([(1, 3), (5, 6)]) == 3.0
    assert core.complement([(2, 4), (6, 7)], 10) == [(0, 2), (4, 6), (7, 10)]
    assert core.complement([], 5) == [(0, 5)]


def test_chapter_offset():
    assert core.mean_abs_offset([0, 60], [0, 70]) == 5.0
    assert core.mean_abs_offset([], [1]) is None and core.mean_abs_offset([1], []) is None


def test_metric_status_follows_the_gate_direction():
    m = core.Metric
    assert m("a", 0.9, gate=0.8).status == "PASS" and m("a", 0.7, gate=0.8).status == "FAIL"
    assert m("a", 3, higher_is_better=False, gate=5).status == "PASS" and m("a", 6, higher_is_better=False, gate=5).status == "FAIL"
    assert m("a", 1).status == "INFO" and m("a", None, gate=1).status == "SKIPPED"


def test_change_since_last_run():
    assert core.change({"value": 1.0}, {"value": 1.5}) == "+0.5"
    assert core.change({"value": 1.0}, {"value": 1.0}) == "" and core.change(None, {"value": 1}) == ""
    assert core.change({"value": None}, {"value": 1}) == ""


@pytest.mark.skipif(not HAS_FFMPEG, reason="ffmpeg not installed")
def test_montage_suite_passes_on_the_current_code():
    from evals.suites import montage
    bad = [m.name for m in montage.run({"live": False}) if m.status == "FAIL"]
    assert bad == []


def test_every_suite_loads_and_returns_metrics_that_can_fail():
    """A suite that crashes would hide itself from the report; one that cannot FAIL measures nothing."""
    import importlib
    import pkgutil

    from evals import suites
    for info in pkgutil.iter_modules(suites.__path__):
        if info.name.startswith("_"):
            continue
        mod = importlib.import_module(f"evals.suites.{info.name}")
        assert mod.NAME and mod.DESCRIPTION
        if info.name == "montage" and not HAS_FFMPEG:
            continue
        metrics = mod.run({"live": False})
        assert metrics and all(isinstance(m, core.Metric) for m in metrics)
        assert any(m.gate is not None for m in metrics), f"{mod.NAME} has no gated metric"
